char* ssid = "jazzBajo";
char* password = "qazxcvbgtrewsdf";
